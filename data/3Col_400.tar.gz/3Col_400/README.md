This is a randomly generated dataset for 3 colorability with 5000 graphs, each of which has 400 vertices.
The 'solvable' directory contains 2500 3-colorable graphs, which all can be turned non-3-colorable by adding a single edge.
The 'unsolvable' directory cointains the 2500 corresponing non-3-colorable graphs with the additional edges.